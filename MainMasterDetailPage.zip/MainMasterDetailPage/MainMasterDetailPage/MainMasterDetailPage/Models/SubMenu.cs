﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MainMasterDetailPage.Models
{
    public class SubMenu
    {
        public string Name { get; set; }
    }
}
